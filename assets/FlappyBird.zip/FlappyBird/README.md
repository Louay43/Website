
How to Run:

1. Download and extract this ZIP file to your Desktop or any folder.

2. Open Command Prompt (Windows):

3. Use the `cd` command to navigate into the extracted folder. Example:

   cd Desktop\flappy-bird-game

4. Run the game with the following command:

   java -jar FlappyBird.jar

(Requires Java installed on your system. You can verify with: java --version)
